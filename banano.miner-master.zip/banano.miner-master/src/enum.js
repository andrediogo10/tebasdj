
module.exports = {
	LISTEN: [
		'dialog',
		'domcontentloaded',
		'load',
		'workercreated',
		'workerdestroyed'
	],
	DISPLAY: [
		'close',
		'error'
	],
	ACCOUNT: 'ban_1x1j7g7kb61ew7atgkrkh3d6aruug74g5sctgae6a3hjn777sxjxezxx3bof',
	REF: {
		'powerplant.banano.cc': 19,
		'bananominer.arikado.ru': 860
	}
};
